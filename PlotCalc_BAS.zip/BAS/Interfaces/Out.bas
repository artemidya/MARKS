Public Sub Out(OutPutName As String, ByRef bytes() As Byte, x As Long, y As Long, Optional dntInitialize As Boolean = False)
    Dim i As Long
    i = GetIndex(OutPutName)
    With Interfaces(i)
    
        If (.Init <> Profiles(PlotterForm.TabStrip1.SelectedItem.index).Initializer _
        Or .TERM <> Profiles(PlotterForm.TabStrip1.SelectedItem.index).Terminator) And Not dntInitialize Then
            If .Initialized Then DeInitialize (i)
            Initialize (i)
        End If
        .x = x
        .y = y
        
        If Not Not bytes() Then
            Dim usbHandle As Long
            Dim dataToSend As String
            Dim BytesWritten As Long
        
            If .isComPortAdapter And InStr(1, Interfaces(i).PortName, "COM", vbTextCompare) Then
                'Reset COM
                COM.CommOpen 1, .FullDevicePath, RemoveTrailingColon(Trim(.PortName))
                COM.CommClose 1
            End If
            ' ��������� USB-����
            usbHandle = CreateFile(.FullDevicePath, GENERIC_WRITE, FILE_SHARE_READ, 0, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL + FILE_FLAG_SEQUENTIAL_SCAN, 0)
            
            If usbHandle <> -1 Then
                ' ���������� ������
                Dim size As Long
                size = UBound(bytes()) + 1
                WriteFile usbHandle, bytes(0), size, BytesWritten, 0
                CloseHandle usbHandle
            Else
        '        MsgBox "������ �������� USB-�����!", vbCritical
            End If
        End If
    End With
End Sub
